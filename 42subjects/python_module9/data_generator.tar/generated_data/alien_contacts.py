"""
Generated test data for alien_contacts
"""

ALIEN_CONTACTS = [
    {
        "contact_id": "AC_2024_001",
        "timestamp": "2024-01-20T00:00:00",
        "location": "Atacama Desert, Chile",
        "contact_type": "visual",
        "signal_strength": 9.6,
        "duration_minutes": 99,
        "witness_count": 11,
        "message_received": "Greetings from Zeta Reticuli",
        "is_verified": false
    },
    {
        "contact_id": "AC_2024_002",
        "timestamp": "2024-08-20T00:00:00",
        "location": "Mauna Kea Observatory, Hawaii",
        "contact_type": "radio",
        "signal_strength": 5.6,
        "duration_minutes": 152,
        "witness_count": 6,
        "message_received": null,
        "is_verified": false
    },
    {
        "contact_id": "AC_2024_003",
        "timestamp": "2024-11-15T00:00:00",
        "location": "Very Large Array, New Mexico",
        "contact_type": "telepathic",
        "signal_strength": 4.5,
        "duration_minutes": 19,
        "witness_count": 14,
        "message_received": null,
        "is_verified": false
    },
    {
        "contact_id": "AC_2024_004",
        "timestamp": "2024-02-24T00:00:00",
        "location": "Roswell, New Mexico",
        "contact_type": "telepathic",
        "signal_strength": 2.4,
        "duration_minutes": 46,
        "witness_count": 9,
        "message_received": null,
        "is_verified": false
    },
    {
        "contact_id": "AC_2024_005",
        "timestamp": "2024-09-10T00:00:00",
        "location": "SETI Institute, California",
        "contact_type": "telepathic",
        "signal_strength": 6.4,
        "duration_minutes": 134,
        "witness_count": 5,
        "message_received": "Warning about solar flare activity",
        "is_verified": false
    },
    {
        "contact_id": "AC_2024_006",
        "timestamp": "2024-02-02T00:00:00",
        "location": "Area 51, Nevada",
        "contact_type": "radio",
        "signal_strength": 2.7,
        "duration_minutes": 20,
        "witness_count": 14,
        "message_received": null,
        "is_verified": false
    },
    {
        "contact_id": "AC_2024_007",
        "timestamp": "2024-03-25T00:00:00",
        "location": "Atacama Desert, Chile",
        "contact_type": "physical",
        "signal_strength": 9.0,
        "duration_minutes": 138,
        "witness_count": 10,
        "message_received": "Request for peaceful contact",
        "is_verified": true
    },
    {
        "contact_id": "AC_2024_008",
        "timestamp": "2024-11-30T00:00:00",
        "location": "Area 51, Nevada",
        "contact_type": "radio",
        "signal_strength": 8.6,
        "duration_minutes": 122,
        "witness_count": 13,
        "message_received": "Unknown language pattern identified",
        "is_verified": true
    },
    {
        "contact_id": "AC_2024_009",
        "timestamp": "2024-09-27T00:00:00",
        "location": "Mauna Kea Observatory, Hawaii",
        "contact_type": "visual",
        "signal_strength": 2.1,
        "duration_minutes": 25,
        "witness_count": 13,
        "message_received": null,
        "is_verified": false
    },
    {
        "contact_id": "AC_2024_010",
        "timestamp": "2024-06-12T00:00:00",
        "location": "Area 51, Nevada",
        "contact_type": "physical",
        "signal_strength": 4.3,
        "duration_minutes": 52,
        "witness_count": 11,
        "message_received": null,
        "is_verified": true
    },
    {
        "contact_id": "AC_2024_011",
        "timestamp": "2024-11-05T00:00:00",
        "location": "Roswell, New Mexico",
        "contact_type": "radio",
        "signal_strength": 3.7,
        "duration_minutes": 235,
        "witness_count": 13,
        "message_received": null,
        "is_verified": false
    },
    {
        "contact_id": "AC_2024_012",
        "timestamp": "2024-07-04T00:00:00",
        "location": "International Space Station",
        "contact_type": "radio",
        "signal_strength": 5.3,
        "duration_minutes": 111,
        "witness_count": 10,
        "message_received": null,
        "is_verified": false
    },
    {
        "contact_id": "AC_2024_013",
        "timestamp": "2024-02-12T00:00:00",
        "location": "Antarctic Research Station",
        "contact_type": "visual",
        "signal_strength": 6.8,
        "duration_minutes": 228,
        "witness_count": 11,
        "message_received": null,
        "is_verified": false
    },
    {
        "contact_id": "AC_2024_014",
        "timestamp": "2024-10-20T00:00:00",
        "location": "Atacama Desert, Chile",
        "contact_type": "radio",
        "signal_strength": 7.2,
        "duration_minutes": 113,
        "witness_count": 8,
        "message_received": "Mathematical sequence detected: prime numbers",
        "is_verified": false
    },
    {
        "contact_id": "AC_2024_015",
        "timestamp": "2024-01-02T00:00:00",
        "location": "Roswell, New Mexico",
        "contact_type": "radio",
        "signal_strength": 2.1,
        "duration_minutes": 9,
        "witness_count": 13,
        "message_received": null,
        "is_verified": false
    }
]
