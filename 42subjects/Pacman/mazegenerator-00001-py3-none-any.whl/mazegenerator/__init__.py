# src/mazegenerator/__init__.py
